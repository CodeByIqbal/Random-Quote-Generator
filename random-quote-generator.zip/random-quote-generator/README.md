# Random Quote Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/CodeByIqbal/pen/poOPWjR](https://codepen.io/CodeByIqbal/pen/poOPWjR).

This project generates a random quote every time the user cliks a button.