const quotes = [  {    quote: "The greatest glory in living lies not in never falling, but in rising every time we fall.",    source: "Nelson Mandela"  },  {    quote: "The way to get started is to quit talking and begin doing.",    source: "Walt Disney"  },  {    quote: "If you can dream it, you can achieve it.",    source: "Zig Ziglar"  },  {    quote: "Believe you can and you're halfway there.",    source: "Theodore Roosevelt"  },  {    quote: "Strive not to be a success, but rather to be of value.",    source: "Albert Einstein"  }];

function getRandomQuote() {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  return quotes[randomIndex];
}

function displayQuote() {
  const quote = getRandomQuote();
  document.getElementById("quote").textContent = quote.quote;
  document.getElementById("source").textContent = quote.source;
}

function getQuote() {
  displayQuote();
}

displayQuote();